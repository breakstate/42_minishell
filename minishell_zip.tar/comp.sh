gcc -g -o minishell minishell.c clean_up.c fake_load.c launcher.c built_ins.c -L ./libft -lft -I ./libft/includes
