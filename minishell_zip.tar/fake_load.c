#include "minishell.h"

void	fake_load(void)
{
	ft_putstr("\n");
	ft_putstr("$> **WELCOME TO MINISHELL**\n");
	ft_putstr(".");
	sleep(1);
	ft_putstr(".");
	sleep(1);
	ft_putendl(".");
}
